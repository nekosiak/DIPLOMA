function Create(){
    this.input1=document.getElementById('input1');
    var inp1=input1.value;
    this.input2=document.getElementById('input2');
    var inp2=input2.value;
    this.input3=document.getElementById('input3');
    var inp3=input3.value;
    alert("Name: "+inp1+"Surname: "+inp2+"Email: "+inp3);
}
let newUser = new Create();
alert(`Your name: ${newUser.inp1}`);
alert(`Your surname: ${newUser.inp2}`);
alert(`Your email: ${newUser.inp3}`);